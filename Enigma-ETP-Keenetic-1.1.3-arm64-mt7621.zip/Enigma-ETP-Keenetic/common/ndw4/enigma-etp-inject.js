/* ENIGMA_ETP_UNIVERSAL_INJECT_V2 */
(()=>{const TOKEN="__ETP_TOKEN__";const sleep=t=>new Promise(r=>setTimeout(r,t));let mounted=false,refreshTimer=0;

const api=async(path,opt={})=>{
  if(location.protocol==="https:")throw Error("ETP API пока доступен только при открытии Keenetic по HTTP");
  let headers={...(opt.headers||{}),"X-Enigma-ETP-Token":TOKEN};
  let url=`http://${location.hostname}:18080${path}`;
  let r;
  try{r=await fetch(url,{...opt,headers,mode:"cors",credentials:"omit"})}
  catch(e){throw Error(`API ETP недоступен (${location.hostname}:18080). Проверьте etp-web и доступ по HTTP`)}
  if(!r.ok)throw Error((await r.text())||`HTTP ${r.status}`);
  let ct=r.headers.get("content-type")||"";
  return ct.includes("json")?r.json():r.text()
};

function getProfileTransport(uri){try{const u=new URL((uri||"").trim());const t=(u.searchParams.get("transport")||"auto").toLowerCase();return ["auto","auto-edge","quic","tcp","http-only","h2","h3"].includes(t)?t:"auto"}catch(e){return "auto"}}

function setProfileTransport(uri,transport){const raw=(uri||"").trim();if(!raw.startsWith("etp://"))throw Error("Профиль должен начинаться с etp://");if(!["auto","auto-edge","quic","tcp","http-only","h2","h3"].includes(transport))throw Error("Неизвестный тип транспорта");try{const u=new URL(raw);u.searchParams.set("transport",transport);return u.toString()}catch(e){let hash="",body=raw;const hi=body.indexOf("#");if(hi>=0){hash=body.slice(hi);body=body.slice(0,hi)}const sep=body.includes("?")?"&":"?";if(/[?&]transport=[^&#]*/i.test(body)){body=body.replace(/([?&])transport=[^&#]*/i,`$1transport=${transport}`)}else{body=body+sep+"transport="+transport}return body+hash}}

function ensureStyles(){
  if(document.getElementById("enigma-etp-native9-style"))return;
  const style=document.createElement("style");
  style.id="enigma-etp-native9-style";
  style.textContent=`
#enigma-etp-native9{margin-top:0}
#enigma-etp-native9 .etp9-card{border-top:1px solid var(--stroke,#465266)}
#enigma-etp-native9 .etp9-row{height:64px;min-height:64px;box-sizing:border-box;padding:0 18px;display:grid;grid-template-columns:minmax(180px,1.2fr) minmax(130px,.8fr) minmax(110px,.7fr) minmax(120px,.7fr) minmax(120px,.7fr) 36px;align-items:center;gap:20px;border-bottom:1px solid var(--stroke,#465266)}
#enigma-etp-native9 .etp9-head{height:48px;min-height:48px;box-sizing:border-box;background:var(--table-header-background,#343d50);font-weight:600;color:var(--secondary-text);border-bottom:0}
#enigma-etp-native9 .etp9-name{display:flex;align-items:center;gap:12px;min-width:0}
#enigma-etp-native9 .etp9-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#enigma-etp-native9 .etp9-status{display:flex;align-items:center;gap:8px;min-width:0}
#enigma-etp-native9 .etp9-dot{width:8px;height:8px;border-radius:50%;background:#7d899a;flex:0 0 auto}
#enigma-etp-native9 .etp9-dot.ok{background:#69ce67}
#enigma-etp-native9 .etp9-settings{width:36px;height:36px;display:flex;align-items:center;justify-content:center;border:2px solid var(--primary-color,#1297d4);border-radius:5px;background:transparent;color:var(--primary-color,#1297d4);cursor:pointer;padding:0;opacity:0;visibility:hidden;transition:opacity .12s ease,visibility .12s ease}
#enigma-etp-native9 .etp9-settings svg{width:16px;height:16px;display:block;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
#enigma-etp-native9 .etp9-row:not(.etp9-head):hover .etp9-settings,#enigma-etp-native9 .etp9-settings:focus-visible{opacity:1;visibility:visible}
#enigma-etp-native9 .etp9-settings:focus-visible{outline:2px solid var(--primary-color,#1297d4);outline-offset:3px}
#enigma-etp-native9 .etp9-toggle{width:38px;height:22px;position:relative;display:inline-block;vertical-align:middle;flex:0 0 auto;border:0;padding:0;margin:0;background:transparent;appearance:none}
#enigma-etp-native9 .etp9-toggle span{position:absolute;inset:0;border-radius:11px;background:#34496a;cursor:pointer;transition:background .15s}
#enigma-etp-native9 .etp9-toggle span:before{content:"";width:20px;height:20px;position:absolute;left:1px;top:1px;border-radius:50%;background:#aab4c1;transition:transform .15s,background .15s}
#enigma-etp-native9 .etp9-toggle[aria-checked="true"] span{background:#34496a}
#enigma-etp-native9 .etp9-toggle[aria-checked="true"] span:before{transform:translateX(16px);background:#079fda}
#enigma-etp-native9 .etp9-error{display:none;padding:10px 16px;color:var(--error,#e34d59);font-size:13px}

.etp9-modal-backdrop{position:fixed;inset:0;z-index:99990;background:#0008;display:flex;justify-content:center;align-items:flex-start;padding:48px 20px;overflow:auto}
.etp9-modal{width:min(720px,calc(100vw - 40px));max-height:calc(100vh - 96px);overflow:auto;background:var(--page-background,#1d2839);border-radius:8px;box-shadow:0 18px 60px #0008;color:var(--primary-text)}
.etp9-modal-header{position:sticky;top:0;z-index:2;padding:28px 32px 20px;background:inherit;display:flex;justify-content:space-between;align-items:flex-start}
.etp9-modal-title{font-size:28px;line-height:36px;font-weight:700;margin:0}
.etp9-modal-desc{margin:8px 0 0;color:var(--secondary-text);font-size:15px;line-height:22px}
.etp9-close{border:0;background:transparent;color:var(--secondary-text);font-size:30px;line-height:1;cursor:pointer;padding:0 0 0 16px}
.etp9-modal-body{padding:0 32px 28px}
.etp9-form-row{margin-top:18px}
.etp9-field-label{display:block;margin-bottom:7px;color:var(--secondary-text);font-size:14px}
.etp9-input,.etp9-textarea,.etp9-select{box-sizing:border-box;width:100%;border:1px solid var(--input-default-border,#5b6778);border-radius:4px;background:var(--input-default-background,transparent);color:var(--primary-text);font:15px/22px inherit;outline:none}
.etp9-input,.etp9-select{height:46px;padding:0 12px}
.etp9-select{appearance:auto}
.etp9-textarea{min-height:150px;padding:10px 12px;font:13px/20px ui-monospace,SFMono-Regular,Menlo,monospace;resize:vertical}
.etp9-input:focus,.etp9-textarea:focus,.etp9-select:focus{border-color:var(--primary-color,#1297d4);box-shadow:0 0 0 1px var(--primary-color,#1297d4)}
.etp9-check-row{display:flex;align-items:center;gap:12px;margin-top:18px}
.etp9-check-row input{width:18px;height:18px;accent-color:var(--primary-color,#1297d4)}
.etp9-advanced-link{margin-top:20px;border:0;background:transparent;color:var(--primary-color,#1297d4);padding:0;cursor:pointer;font:inherit}
.etp9-advanced{display:none}
.etp9-advanced.open{display:block}
.etp9-modal-error{display:none;margin-top:14px;color:var(--error,#e34d59);font-size:13px;white-space:pre-wrap}
.etp9-modal-footer{position:sticky;bottom:0;display:flex;justify-content:flex-end;gap:12px;padding:18px 32px;background:var(--page-background,#1d2839);border-top:1px solid var(--stroke,#465266)}
.etp9-btn{height:36px;padding:0 18px;border:1px solid var(--primary-color,#1297d4);border-radius:4px;background:var(--primary-color,#1297d4);color:#fff;font:inherit;cursor:pointer}
.etp9-btn.outline{background:transparent;color:var(--primary-color,#1297d4)}
@media(max-width:1000px){#enigma-etp-native9 .etp9-row{grid-template-columns:minmax(180px,1fr) minmax(120px,.8fr) minmax(100px,.7fr) 36px}#enigma-etp-native9 .etp9-col-hide{display:none}}
@media(max-width:620px){.etp9-modal-backdrop{padding:0}.etp9-modal{width:100%;max-height:100vh;min-height:100vh;border-radius:0}.etp9-modal-header,.etp9-modal-body,.etp9-modal-footer{padding-left:18px;padding-right:18px}#enigma-etp-native9 .etp9-row{grid-template-columns:1fr auto 36px;padding:8px 10px;gap:10px}.etp9-mobile-hide{display:none}}
`;
  document.head.appendChild(style)
}

function toggleMarkup(id){return `<button id="${id}" class="etp9-toggle" type="button" role="switch" aria-checked="false" aria-label="Включить или выключить подключение"><span aria-hidden="true"></span></button>`}

function findETPMountHost(){
  /*
   * Known NDW4 components. Keep the old component first so existing
   * Keenetic models retain exactly the same insertion point.
   */
  const selectors=[
    "ndw-ipv6-in-4",
    "ndw-ipv6-over-ipv4",
    "ndw-ipv6-in-ipv4",
    "ndw-ipv6-over-ipv4-configuration",
    "ndw-ipv6-in-ipv4-configuration",
    "ndw-wireguard",
    "ndw-wireguard-connection",
    "ndw-wireguard-configuration",
    "ndw-openvpn",
    "ndw-openvpn-connection",
    "ndw-openvpn-configuration"
  ];

  for(const selector of selectors){
    const el=document.querySelector(selector);
    if(el)return el;
  }

  /*
   * Firmware builds may rename Angular custom elements while preserving
   * protocol names in their tag names. Search only inside the current
   * NDW page, never across unrelated application chrome.
   */
  const page=document.querySelector("ndw-page-wrapper");
  if(!page)return null;

  const protocolNames=[
    "WIREGUARD",
    "OPENVPN",
    "IPV6-IN-4",
    "IPV6-IN-IPV4",
    "IPV6-OVER-IPV4"
  ];

  for(const el of page.querySelectorAll("*")){
    const tag=(el.tagName||"").toUpperCase();

    if(!tag.startsWith("NDW-"))continue;

    if(protocolNames.some(name=>tag.includes(name))){
      return el;
    }
  }

  /*
   * Last structural fallback. Some NDW releases keep protocol names only
   * in CSS classes. Return the nearest NDW component rather than the
   * inner decorative element so insertion remains at section level.
   */
  const structural=page.querySelector(
    '[class*="ipv6-in-4"],'+
    '[class*="ipv6-over-ipv4"],'+
    '[class*="wireguard"],'+
    '[class*="openvpn"]'
  );

  if(structural){
    let el=structural;

    while(el&&el!==page){
      if((el.tagName||"").toUpperCase().startsWith("NDW-")){
        return el;
      }
      el=el.parentElement;
    }
  }

  return null;
}

function findETPInsertReference(host){
  /*
   * Keep ETP in the same layout container as the detected native protocol
   * section.  NDMS 5.1.4 adds page-level wrappers with their own gutters;
   * climbing to those wrappers makes the injected row start at the viewport
   * edge instead of the native content column.
   */
  return host||null;
}

function build(){
  if(mounted&&document.getElementById("enigma-etp-native9"))return;

  const host=findETPMountHost();
  if(!host)return;

  const ref=findETPInsertReference(host);
  if(!ref||!ref.parentNode)return;

  ensureStyles();

  let sec=document.createElement("section");
  sec.id="enigma-etp-native9";
  sec.innerHTML=`
    <h2 style="margin:28px 0 10px;font-size:20px">Enigma ETP</h2>
    <p style="margin:0 0 18px;color:var(--secondary-text)">Подключение к Интернету через протокол ETP.</p>
    <div class="etp9-card">
      <div class="etp9-row etp9-head">
        <div>Подключение</div>
        <div>Адрес</div>
        <div class="etp9-col-hide">Транспорт</div>
        <div class="etp9-col-hide">Состояние</div>
        <div class="etp9-mobile-hide">Интерфейс</div>
        <div></div>
      </div>
      <div class="etp9-row">
        <div class="etp9-name">${toggleMarkup("etp9-enable")}<span class="etp9-label">Enigma ETP</span></div>
        <div id="etp9-address">—</div>
        <div id="etp9-transport" class="etp9-col-hide">—</div>
        <div class="etp9-status etp9-col-hide"><span id="etp9-dot" class="etp9-dot"></span><span id="etp9-state">Получение состояния…</span></div>
        <div id="etp9-interface" class="etp9-mobile-hide">OpkgTun0</div>
        <button id="etp9-settings" class="etp9-settings" type="button" title="Настройки" aria-label="Настройки">
          <svg viewBox="0 0 32 32" aria-hidden="true"><path d="M5 27l2.2-7.4L22.7 4.1a2.8 2.8 0 014 0l1.2 1.2a2.8 2.8 0 010 4L12.5 24.7 5 27z"/><path d="M19.8 7l5.2 5.2M8 20l4 4M5 27l4-1"/></svg>
        </button>
      </div>
      <div id="etp9-error" class="etp9-error"></div>
    </div>`;

  ref.parentNode.insertBefore(sec,ref.nextSibling);
  mounted=true;

  const enable=sec.querySelector("#etp9-enable");
  const err=sec.querySelector("#etp9-error");
  let busy=false;

  const fail=e=>{err.textContent=e?.message||String(e);err.style.display="block"};
  const clearError=()=>{err.style.display="none";err.textContent=""};

  const action=async a=>{
    if(busy)return;
    busy=true;clearError();
    try{
      await api("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:a})});
      await sleep(700);await refresh()
    }catch(e){fail(e)}
    finally{busy=false}
  };

  async function refresh(){
    try{
      let [s,nm]=await Promise.all([api("/api/status"),api("/api/name")]);
      enable.setAttribute("aria-checked",s.tunnelActive?"true":"false");
      sec.querySelector(".etp9-label").textContent=(nm&&nm.name)||"Enigma ETP";
      sec.querySelector("#etp9-address").textContent=s.server||"—";
      sec.querySelector("#etp9-interface").textContent=s.interface||"OpkgTun0";
		let t=({auto:"Авто","auto-edge":"Авто + Edge",quic:"QUIC",tcp:"TCP",h2:"HTTP/2",h3:"HTTP/3","http-only":"HTTP Edge"}[s.transport]||s.transport||"Авто");
      sec.querySelector("#etp9-transport").textContent=t;
      let connected=!!s.tunnelActive;
      sec.querySelector("#etp9-state").textContent=connected?"Подключено":"Отключено";
      sec.querySelector("#etp9-dot").classList.toggle("ok",connected);
      clearError()
    }catch(e){sec.querySelector("#etp9-state").textContent="Ошибка";fail(e)}
  }

  async function openModal(){
    clearError();
    const [st,pr,nm,plist]=await Promise.all([api("/api/status"),api("/api/profile"),api("/api/name"),api("/api/profiles")]);

    const back=document.createElement("div");
    back.className="etp9-modal-backdrop";
    back.innerHTML=`
      <div class="etp9-modal" role="dialog" aria-modal="true">
        <div class="etp9-modal-header">
          <div>
            <h2 class="etp9-modal-title">Настройки подключения</h2>
            <p class="etp9-modal-desc">Укажите параметры подключения Enigma ETP.</p>
          </div>
          <button class="etp9-close" type="button" aria-label="Закрыть">×</button>
        </div>
        <div class="etp9-modal-body">
          <div class="etp9-form-row">
            <label class="etp9-field-label">Имя</label>
            <input id="etp9-modal-name" class="etp9-input" value="">
          </div>

          <label class="etp9-check-row">
            <input id="etp9-modal-endpoint" type="checkbox" ${st.endpoint?"checked":""}>
            <span>Использовать для выхода в интернет</span>
          </label>

          <div class="etp9-form-row">
            <label class="etp9-field-label">Профиль</label>
            <div style="display:flex;gap:8px;align-items:center">
              <select id="etp9-profile-select" class="etp9-select" style="flex:1"></select>
              <button id="etp9-profile-add" class="etp9-btn outline" type="button">Добавить профиль</button>
              <button id="etp9-profile-delete" class="etp9-btn outline" type="button">Удалить</button>
            </div>
          </div>

          <div class="etp9-form-row">
            <label class="etp9-field-label">ETP-профиль</label>
            <textarea id="etp9-modal-profile" class="etp9-textarea" spellcheck="false" autocomplete="off" placeholder="etp://…"></textarea>
          </div>

          <div class="etp9-form-row">
            <label class="etp9-field-label">Транспорт</label>
            <select id="etp9-modal-transport" class="etp9-select">
              <option value="auto">Авто</option>
			  <option value="auto-edge">Авто + Edge</option>
              <option value="quic">QUIC</option>
              <option value="tcp">TCP</option>
              <option value="http-only">HTTP Edge</option>
              <option value="h2">HTTP/2 Edge</option>
              <option value="h3">HTTP/3 Edge</option>
            </select>
          </div>

          <button id="etp9-advanced-link" class="etp9-advanced-link" type="button">Показать дополнительные настройки⌄</button>

          <div id="etp9-advanced" class="etp9-advanced">
            <div class="etp9-form-row"><label class="etp9-field-label">Интерфейс</label><input class="etp9-input" value="${st.interface||"OpkgTun0"}" disabled></div>
            <div class="etp9-form-row"><label class="etp9-field-label">Адрес туннеля</label><input class="etp9-input" value="${st.address||"198.18.0.1"}" disabled></div>
            <div class="etp9-form-row"><label class="etp9-field-label">Транспорт</label><input class="etp9-input" value="${({auto:"Авто",quic:"QUIC",tcp:"TCP"}[st.transport]||st.transport||"Авто")}" disabled></div>
            <div class="etp9-form-row"><label class="etp9-field-label">MTU</label><input class="etp9-input" value="${st.mtu||1280}" disabled></div>
          </div>

          <div class="etp9-form-row">
            <label class="etp9-field-label">Обновление клиента Keenetic</label>
            <button id="etp9-update" class="etp9-btn outline" type="button">Проверить обновление</button>
            <div id="etp9-update-status" style="margin-top:8px;color:var(--secondary-text);font-size:13px" aria-live="polite"></div>
          </div>

          <div id="etp9-modal-error" class="etp9-modal-error"></div>
        </div>
        <div class="etp9-modal-footer">
          <button id="etp9-modal-restart" class="etp9-btn outline" type="button">Переподключить</button>
          <button id="etp9-modal-save" class="etp9-btn" type="button">Сохранить</button>
        </div>
      </div>`;

    document.body.appendChild(back);

    const nameInput=back.querySelector("#etp9-modal-name");
    const profileSelect=back.querySelector("#etp9-profile-select");
    const profiles=Array.isArray(plist?.profiles)?plist.profiles:[];
    profiles.forEach(p=>{
      const option=document.createElement("option");
      option.value=p.id;
      option.textContent=(p.name||p.id)+" ("+(p.transport||"auto")+")";
      profileSelect.appendChild(option);
    });
    if(plist?.active) profileSelect.value=plist.active;
    if(!profileSelect.value && profiles[0]) profileSelect.value=profiles[0].id;
    const selectedProfile=()=>profiles.find(p=>p.id===profileSelect.value);
    nameInput.value=(selectedProfile()?.name||nm?.name||"Enigma ETP").trim();
    const profile=back.querySelector("#etp9-modal-profile");
    profile.value=(pr&&typeof pr.profile==="string")?pr.profile:"";
    const transport=back.querySelector("#etp9-modal-transport");
    transport.value=getProfileTransport(profile.value||"");
    const modalErr=back.querySelector("#etp9-modal-error");
    const modalFail=e=>{modalErr.textContent=e?.message||String(e);modalErr.style.display="block"};
    const deleteButton=back.querySelector("#etp9-profile-delete");
    const updateDeleteButton=()=>{
      const selected=selectedProfile();
      deleteButton.disabled=!selected||selected.active||selected.newProfile;
      deleteButton.title=selected?.active?"Сначала выберите другой активный профиль":"Удалить выбранный профиль";
    };
    updateDeleteButton();
    back.querySelector("#etp9-profile-add").addEventListener("click",()=>{
      let id=window.prompt("Идентификатор нового профиля", "legacy");
      if(id===null) return;
      id=id.trim().replace(/[^A-Za-z0-9_-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,32);
      if(!id){modalFail(Error("Укажите корректный идентификатор профиля"));return}
      if(profiles.some(p=>p.id===id)){modalFail(Error("Профиль с таким идентификатором уже существует"));return}
      const item={id,name:id,transport:"auto",server:"",active:false,newProfile:true};
      profiles.push(item);
      const option=document.createElement("option");
      option.value=id;
      option.textContent=id+" (новый)";
      profileSelect.appendChild(option);
      profileSelect.value=id;
      profile.value="";
      transport.value="auto";
      nameInput.value=id;
      updateDeleteButton();
      modalErr.style.display="none";
    });
    deleteButton.addEventListener("click",async()=>{
      const selected=selectedProfile();
      if(!selected||selected.active) return;
      if(selected.newProfile){
        const option=Array.from(profileSelect.options).find(o=>o.value===selected.id);
        if(option) option.remove();
        profiles.splice(profiles.indexOf(selected),1);
        profileSelect.value=plist.active||profiles[0]?.id||"";
        profileSelect.dispatchEvent(new Event("change"));
        updateDeleteButton();
        return;
      }
      if(!window.confirm(`Удалить профиль «${selected.name||selected.id}»?`)) return;
      modalErr.style.display="none";
      try{
        await api("/api/profiles?id="+encodeURIComponent(selected.id),{method:"DELETE"});
        const option=Array.from(profileSelect.options).find(o=>o.value===selected.id);
        if(option) option.remove();
        profiles.splice(profiles.indexOf(selected),1);
        profileSelect.value=plist.active||profiles[0]?.id||"";
        if(profileSelect.value) profileSelect.dispatchEvent(new Event("change"));
        updateDeleteButton();
      }catch(e){modalFail(e)}
    });
    profile.addEventListener("change",()=>{transport.value=getProfileTransport(profile.value)});
    profileSelect.addEventListener("change",async()=>{
      modalErr.style.display="none";
      try{
        const selected=selectedProfile();
        if(selected?.newProfile){
          profile.value="";
          transport.value="auto";
          nameInput.value=selected.name||selected.id;
          return;
        }
        const item=await api("/api/profiles?id="+encodeURIComponent(profileSelect.value));
        profile.value=item.profile||"";
        transport.value=getProfileTransport(profile.value);
        if(selected?.name) nameInput.value=selected.name;
        updateDeleteButton();
      }catch(e){modalFail(e)}
    });
    const close=()=>back.remove();

    back.querySelector(".etp9-close").addEventListener("click",close);
    back.addEventListener("click",e=>{if(e.target===back)close()});

    back.querySelector("#etp9-advanced-link").addEventListener("click",e=>{
      let adv=back.querySelector("#etp9-advanced");
      let open=adv.classList.toggle("open");
      e.currentTarget.textContent=open?"Скрыть дополнительные настройки⌃":"Показать дополнительные настройки⌄"
    });

    back.querySelector("#etp9-modal-restart").addEventListener("click",async()=>{
      modalErr.style.display="none";
      try{
        await api("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"restart"})});
        await sleep(900);await refresh()
      }catch(e){modalFail(e)}
    });

    back.querySelector("#etp9-update").addEventListener("click",async()=>{
      const button=back.querySelector("#etp9-update");
      const status=back.querySelector("#etp9-update-status");
      button.disabled=true;
      modalErr.style.display="none";
      try{
        status.textContent="Проверка выпуска GitHub…";
        const info=await api("/api/update");
        if(!info.available){status.textContent=`Установлена актуальная версия ${info.current}.`;return}
        if(!window.confirm(`Обновить клиент Keenetic с ${info.current} до ${info.latest}? Профили и маршруты сохранятся, туннель кратковременно прервётся.`)){
          status.textContent="Обновление отменено";return;
        }
        await api("/api/update",{method:"POST"});
        button.textContent="Обновление выполняется";
        for(let attempt=0;attempt<100;attempt++){
          await sleep(3000);
          let state;
          try{state=await api("/api/update-status")}catch(e){status.textContent="Служба перезапускается…";continue}
          status.textContent=state.message||state.status;
          if(state.status==="complete"){
            status.textContent=`Клиент обновлён до ${state.version}. Страница перезагрузится.`;
            await sleep(1500);location.reload();return;
          }
          if(state.status==="failed")throw Error(state.message||"Обновление не удалось");
        }
        throw Error("Проверка обновления заняла слишком много времени. Проверьте состояние позже.");
      }catch(e){modalFail(e);status.textContent="Обновление не завершено"}
      finally{button.disabled=false;button.textContent="Проверить обновление"}
    });

    back.querySelector("#etp9-modal-save").addEventListener("click",async()=>{
      modalErr.style.display="none";
      let uri=profile.value.trim();
      if(!uri.startsWith("etp://")){modalFail(Error("Профиль должен начинаться с etp://"));return}
      try{
        let name=nameInput.value.trim()||"Enigma ETP";
        if(name.length>64){modalFail(Error("Имя не должно быть длиннее 64 символов"));return}
        await api("/api/name",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name})});
        uri=setProfileTransport(uri,transport.value);
        profile.value=uri;
        const profileID=profileSelect.value.trim()||"default";
        await api("/api/profiles",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:profileID,name,uri})});
        await api("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"profile-select",profileId:profileID})});
        const endpoint=back.querySelector("#etp9-modal-endpoint").checked;
        if(endpoint!==!!st.endpoint){
          await api("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:endpoint?"endpoint-enable":"endpoint-disable"})})
        }
        await sleep(500);await refresh();close()
      }catch(e){modalFail(e)}
    });
  }

  enable.addEventListener("click",()=>{const next=enable.getAttribute("aria-checked")!=="true";enable.setAttribute("aria-checked",next?"true":"false");action(next?"start":"stop")});
  sec.querySelector("#etp9-settings").addEventListener("click",()=>openModal().catch(fail));
  refresh();
  refreshTimer=setInterval(()=>document.body.contains(sec)?refresh():(clearInterval(refreshTimer),mounted=false),5000)
}

const scan=()=>{if(!document.getElementById("enigma-etp-native9"))build()};
setTimeout(scan,500);
new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true})
})();
