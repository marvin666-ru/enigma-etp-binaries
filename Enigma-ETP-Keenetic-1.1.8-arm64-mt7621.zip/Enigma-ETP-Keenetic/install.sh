#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ACTION="${1:-install}"

case "$ACTION" in
    install|update|uninstall) ;;
    *) echo "Usage: ./install.sh [install|update|uninstall]" >&2; exit 2 ;;
esac

if [ "$ACTION" = uninstall ]; then
    [ -d /opt ] || { echo "ERROR: /opt is unavailable." >&2; exit 1; }
    if [ -x /opt/etc/init.d/S97enigma-etp-ndw4 ]; then
        /opt/bin/sh /opt/etc/init.d/S97enigma-etp-ndw4 stop || {
            echo "ERROR: WebUI patch could not be removed; uninstall aborted." >&2
            exit 1
        }
    fi
    if [ -x /opt/etc/init.d/S99enigma-etp ]; then
        /opt/bin/sh /opt/etc/init.d/S99enigma-etp endpoint-disable || true
    fi
    for service in S98enigma-etp-web S99enigma-etp; do
        if [ -x "/opt/etc/init.d/$service" ]; then
            /opt/bin/sh "/opt/etc/init.d/$service" stop || true
        fi
    done
    if [ -f "$ROOT/common/initrc" ] && [ -f /opt/etc/initrc ] &&
       cmp -s "$ROOT/common/initrc" /opt/etc/initrc; then
        rm -f /opt/etc/initrc
    fi
    rm -f \
        /opt/bin/etp-keenetic \
        /opt/bin/etp-web \
        /opt/bin/etpctl \
        /opt/etc/init.d/S97enigma-etp-ndw4 \
        /opt/etc/init.d/S98enigma-etp-web \
        /opt/etc/init.d/S99enigma-etp \
        /opt/etc/ndm/wan.d/020-enigma-etp \
        /opt/etc/enigma-etp/ndw4/enigma-etp-inject.js \
        /opt/etc/enigma-etp/client-version
    echo "Enigma ETP client removed. Profiles, API token, logs and backups were preserved."
    echo "User-defined routes via OpkgTun0 were not changed."
    echo "Shared hev-socks5-tunnel was not removed."
    exit 0
fi

echo "=== Enigma ETP for Keenetic ==="

ARCH="$(uname -m 2>/dev/null || true)"
CPUINFO="$(cat /proc/cpuinfo 2>/dev/null || true)"

case "$ARCH" in
    aarch64|arm64)
        PLATFORM="arm64"
        ;;
    mips|mipsel|mipsle)
        if echo "$CPUINFO" | grep -qiE 'MT7621|1004K'; then
            PLATFORM="mt7621"
        else
            echo "ERROR: unsupported MIPS platform." >&2
            echo "This package supports MT7621/MT7621DA only." >&2
            exit 1
        fi
        ;;
    *)
        echo "ERROR: unsupported architecture: $ARCH" >&2
        exit 1
        ;;
esac

echo "Detected platform: $PLATFORM"

[ -d /opt ] || {
    echo "ERROR: /opt is unavailable." >&2
    echo "Enable Open Package support in KeeneticOS first." >&2
    exit 1
}

mkdir -p \
    /opt/bin \
    /opt/etc/enigma-etp \
    /opt/etc/enigma-etp/profiles \
    /opt/etc/enigma-etp/ndw4 \
    /opt/etc/init.d \
    /opt/etc/ndm/wan.d \
    /opt/var/log \
    /opt/var/run \
    /opt/var/lib/enigma-etp

WEB_TOKEN=/opt/etc/enigma-etp/web-token.txt

ensure_web_token() {
    if [ -s "$WEB_TOKEN" ]; then
        TOKEN_VALUE="$(cat "$WEB_TOKEN" 2>/dev/null || true)"
        case "$TOKEN_VALUE" in
            ''|*[!A-Za-z0-9_-]*)
                echo "ERROR: existing WebUI token is invalid; it was not replaced." >&2
                return 1
                ;;
        esac
        unset TOKEN_VALUE
        return 0
    fi

    [ -x /opt/bin/busybox ] || {
        echo "ERROR: /opt/bin/busybox is missing; initialize Entware first." >&2
        return 1
    }
    umask 077
    # Keenetic's BusyBox od supports -x but not GNU od's -A/-t options.
    # Skip the offset field on each line and keep only the random hex words.
    TOKEN_VALUE="$(/opt/bin/busybox dd if=/dev/urandom bs=24 count=1 2>/dev/null |
        /opt/bin/busybox od -x |
        /opt/bin/busybox awk '{ for (i = 2; i <= NF; i++) printf "%s", $i }' || true)"
    [ "${#TOKEN_VALUE}" -eq 48 ] || {
        echo "ERROR: could not generate WebUI token." >&2
        return 1
    }
    TOKEN_TEMP="$WEB_TOKEN.etp-new.$$"
    printf '%s\n' "$TOKEN_VALUE" >"$TOKEN_TEMP"
    chmod 600 "$TOKEN_TEMP"
    mv -f "$TOKEN_TEMP" "$WEB_TOKEN"
    unset TOKEN_VALUE TOKEN_TEMP
    echo "WebUI API token initialized."
}

install_file() {
    src="$1"
    dst="$2"
    [ -f "$src" ] || return 0
    # Rename into place: the updater itself may be running from etp-web.
    cp -p "$src" "$dst.etp-new"
    mv -f "$dst.etp-new" "$dst"
}

stop_services() {
    # Unmount the injected bundle before replacing the payload. Otherwise
    # S97 sees the old marker and keeps serving the previous WebUI code.
    [ -x /opt/etc/init.d/S97enigma-etp-ndw4 ] && \
        /opt/bin/sh /opt/etc/init.d/S97enigma-etp-ndw4 stop >/dev/null 2>&1 || true
    [ -x /opt/etc/init.d/S98enigma-etp-web ] && \
        /opt/bin/sh /opt/etc/init.d/S98enigma-etp-web stop >/dev/null 2>&1 || true
    [ -x /opt/etc/init.d/S99enigma-etp ] && \
        /opt/bin/sh /opt/etc/init.d/S99enigma-etp stop >/dev/null 2>&1 || true
}

start_services() {
    if [ -x /opt/etc/init.d/S98enigma-etp-web ]; then
        /opt/bin/sh /opt/etc/init.d/S98enigma-etp-web start || \
            echo "WARNING: ETP Web API did not start; check /opt/var/log/enigma-etp-web.log" >&2
    fi
    if [ -x /opt/etc/init.d/S97enigma-etp-ndw4 ]; then
        /opt/bin/sh /opt/etc/init.d/S97enigma-etp-ndw4 start || \
            echo "WARNING: ETP WebUI integration failed; check /opt/var/log/enigma-etp-ndw4.log" >&2
    fi
    if [ -s /opt/etc/enigma-etp/profile.txt ] && [ -x /opt/etc/init.d/S99enigma-etp ]; then
        /opt/bin/sh /opt/etc/init.d/S99enigma-etp start || true
    fi
}

ensure_web_token
stop_services

install_file "$ROOT/$PLATFORM/etp-keenetic" /opt/bin/etp-keenetic
install_file "$ROOT/$PLATFORM/etp-web" /opt/bin/etp-web

if [ "$PLATFORM" = "arm64" ]; then
    install_file "$ROOT/arm64/hev-socks5-tunnel" /opt/bin/hev-socks5-tunnel
else
    if [ ! -x /opt/bin/hev-socks5-tunnel ]; then
        if command -v opkg >/dev/null 2>&1; then
            echo "Installing hev-socks5-tunnel for MT7621..."
            opkg update
            opkg install hev-socks5-tunnel
        else
            echo "ERROR: hev-socks5-tunnel is missing and opkg is unavailable." >&2
            exit 1
        fi
    fi
fi

install_file "$ROOT/common/etpctl" /opt/bin/etpctl
install_file "$ROOT/common/S97enigma-etp-ndw4" /opt/etc/init.d/S97enigma-etp-ndw4
install_file "$ROOT/common/S98enigma-etp-web" /opt/etc/init.d/S98enigma-etp-web
install_file "$ROOT/common/S99enigma-etp" /opt/etc/init.d/S99enigma-etp
install_file "$ROOT/common/020-enigma-etp" /opt/etc/ndm/wan.d/020-enigma-etp
install_file "$ROOT/common/initrc" /opt/etc/initrc
install_file "$ROOT/VERSION" /opt/etc/enigma-etp/client-version

if [ -f "$ROOT/common/ndw4/enigma-etp-inject.js" ]; then
    install_file "$ROOT/common/ndw4/enigma-etp-inject.js" \
        /opt/etc/enigma-etp/ndw4/enigma-etp-inject.js
fi

chmod 755 /opt/bin/etp-keenetic /opt/bin/etp-web /opt/bin/hev-socks5-tunnel 2>/dev/null || true
chmod 755 /opt/bin/etpctl 2>/dev/null || true
chmod 755 /opt/etc/init.d/S97enigma-etp-ndw4 2>/dev/null || true
chmod 755 /opt/etc/init.d/S98enigma-etp-web 2>/dev/null || true
chmod 755 /opt/etc/init.d/S99enigma-etp 2>/dev/null || true
chmod 755 /opt/etc/ndm/wan.d/020-enigma-etp 2>/dev/null || true
chmod 755 /opt/etc/initrc 2>/dev/null || true

if [ ! -f /opt/etc/enigma-etp/profile.txt ]; then
    : > /opt/etc/enigma-etp/profile.txt
fi
chmod 600 /opt/etc/enigma-etp/profile.txt 2>/dev/null || true
chmod 700 /opt/etc/enigma-etp/profiles 2>/dev/null || true

start_services

echo
echo "Installation complete."
echo "Set profile:"
echo "  etpctl profile set 'etp://...'"
echo
echo "Start:"
echo "  etpctl start"
echo
echo "Status:"
echo "  etpctl status"
echo
echo "Diagnostics:"
echo "  etpctl diag"
