#!/usr/bin/env bash
set -euo pipefail

METRICS_BINARY="${1:?metrics journal binary required}"
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo 'Run as root.' >&2; exit 1; }
[[ -x "$METRICS_BINARY" ]] || { echo "Missing executable: $METRICS_BINARY" >&2; exit 1; }
id enigma-etp >/dev/null 2>&1 || { echo 'Missing enigma-etp service user.' >&2; exit 1; }
systemctl cat enigma-etp.service >/dev/null

install -d -o enigma-etp -g enigma-etp -m 0700 /var/log/enigma-etp
install -m 0755 "$METRICS_BINARY" /usr/local/bin/etp-metrics-journal.etp-new
mv -f /usr/local/bin/etp-metrics-journal.etp-new /usr/local/bin/etp-metrics-journal

cat > /etc/systemd/system/enigma-etp-metrics.service <<'UNIT'
[Unit]
Description=Enigma ETP diagnostic metrics journal
After=enigma-etp.service
Requires=enigma-etp.service

[Service]
Type=simple
User=enigma-etp
Group=enigma-etp
UMask=0077
ExecStart=/usr/local/bin/etp-metrics-journal -url http://127.0.0.1:9090/metrics -dir /var/log/enigma-etp -interval 10s -retention 336h -max-bytes 524288000
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/log/enigma-etp
RestrictAddressFamilies=AF_INET AF_UNIX AF_NETLINK
CapabilityBoundingSet=

[Install]
WantedBy=multi-user.target
UNIT
chmod 0644 /etc/systemd/system/enigma-etp-metrics.service
systemd-analyze verify /etc/systemd/system/enigma-etp-metrics.service
systemctl daemon-reload
systemctl enable --now enigma-etp-metrics.service
systemctl restart enigma-etp-metrics.service
systemctl is-active --quiet enigma-etp-metrics.service
echo 'ETP metrics journal active: /var/log/enigma-etp (6-hour files, 14 days, 500 MiB limit).'
