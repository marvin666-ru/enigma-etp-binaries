# UDP diagnostics for Enigma ETP VPS

This package updates only `enigma-etp-metrics.service`. It does not restart
`enigma-etp.service` or `enigma-edge.service`, and does not read or replace
tokens, profiles, certificates, or server configuration. Requires an existing
Enigma ETP installation, `systemd`, and `ss` (iproute2).

On the VPS, unpack the archive and run from its directory:

```bash
arch="$(uname -m)"
case "$arch" in
  x86_64|amd64) arch=amd64 ;;
  aarch64|arm64) arch=arm64 ;;
  *) echo "Unsupported architecture: $arch" >&2; exit 1 ;;
esac
command -v ss >/dev/null || { echo 'Install iproute2 first'; exit 1; }
sudo bash ./install-metrics-journal.sh "./bin/$arch/etp-metrics-journal"
```

After 20 seconds, verify:

```bash
sudo systemctl is-active enigma-etp-metrics.service
sudo tail -n 3 /var/log/enigma-etp/metrics-*.log
```

The new fields are `udp_443_rx_queued_bytes`, `udp_443_rcvbuf_bytes`,
`delta_udp_443_socket_drops` and the same three for UDP/8444 (HTTP Edge).
`delta_udp_rcvbuf_errors` remains a VPS-wide counter and may include unrelated
services. `udp_socket_status=unavailable` means the socket probe failed, not
that drops were zero. The service samples every 10 seconds, rotates files every
six UTC hours, retains up to 14 days and caps the total at 500 MiB.

If Edge uses a non-default UDP port, change `-udp-ports 443,8444` in the
`ExecStart` line of `/etc/systemd/system/enigma-etp-metrics.service`, then run
`sudo systemctl daemon-reload && sudo systemctl restart enigma-etp-metrics.service`.
